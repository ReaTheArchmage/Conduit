## Standard class used to emit signals, has connect and emit extension
## methods.
class_name Emitter extends Node
@warning_ignore("unused_signal")
## Singnal emitted in absence of other signals.
signal default_emitter_signal()

var classes                      : Array[Object] = [self, SignalBus]
@export var signal_registry      : Package
@export var enable_connections   : bool

@onready var ir_connect_couples = connect_couples(signal_registry
) if enable_connections else false

## Emits global/local/default grouped signals, can loop emission.
func group_emit(
	signals: Array[StringName], args,
	looped: bool, delay_duration: float = 2.0):

	for s in signals:

		if self.has_signal(s):
			self.emit_signal(s, args)

		elif SignalBus.has_signal(s):
			SignalBus.emit_signal(s, args)

		else:
			default_emitter_signal.emit(args)

	if looped:
		await get_tree().create_timer(delay_duration).timeout
		group_emit(signals, args, looped, delay_duration)

## Connects signal/method couples from signal_registry.couples 
func connect_couples(pkg: Package) -> bool:

	var couples = pkg.couples
	for signal_name in couples: for _class in classes:

		var method_name: StringName = couples[signal_name]
		var sig
		var callable 

		if _class.has_signal(signal_name):
			sig = Signal(_class, signal_name)
		else: return false

		if _class.has_method(method_name):
			callable = Callable(_class, method_name)
		else: return false

		if not sig.is_connected(callable):
			sig.connect(callable)

	return true

# TEST group_emit (looped):
#func _ready() -> void: group_emit(true)
# TEST group_emit (non looped):
#func _ready() -> void: group_emit(false)
# function:
#var v = 0
#func test_method():
	#v += 1
	#print("Signal Heard: ", v)
