## Emitter that is already connected to area_entered/exited signals.
class_name AreaEmitter extends Emitter

@warning_ignore("unused_signal")
signal area_in_group(area: Area3D)

@export_category("AreaSignal")
@export var group_to_check: String
@export var push_warnings: bool = true
@export var connect_to_signal: bool = true

## Implicit ready call to area setup.
@onready var ir_area_setup = area_setup()
func area_setup():
	connect_couples(
		Static.Resources.Default.DEF_AREA_EMITTER_PKG) 

## Signal hooks, they get connected to internal Area3D signals:
func _on_area_entered(area: Area3D) -> void:  area_entered_emit(area)
func _on_area_exited(area: Area3D)  -> void:  area_entered_emit(area)

## Emits a signal when the entered area matches the specified @export group_to_check String.
func area_entered_emit(area: Area3D):

	if area.is_in_group(group_to_check):
		print("ok area")
		group_emit([&"area_in_group"], area, false)

func connection_safety() -> bool:

	var return_conditions: Dictionary[int, bool] = {
		0 : false, 1 : false}

	for i in return_conditions: match i:

		0: # check if given group name is valid and matches an existing group.
			var condition_1: bool
			condition_1 = (
				true if group_to_check
				and     group_to_check
				in      Static.Utility.get_all_global_groups()
				else false)
			return_conditions[i] = condition_1

		1: # check for any CollisionShape children.
			var condition_2: bool
			for child in self.get_children():
				condition_2 = (
					true if child is CollisionShape3D else condition_2)
			return_conditions[i] = condition_2

	var call_condition_check = condition_check(
		return_conditions.values())
	if not call_condition_check: return false

	return true

func condition_check(gate_bool_state: Array[bool]) -> bool:

	var cond_index: int = 0
	for cond in gate_bool_state:
		cond_index += 1

		if not cond: match cond_index:
			1:
				if push_warnings: Static.Emitters.warning(
					0, name)
				return false
			2:
				if push_warnings: Static.Emitters.warning(
					1, name)
				return false

	return true
