## Container of all static data/fuctions. Divided in subclasses.
class_name Static extends Node

class Resources:

	class Default:
		const DEF_AREA_EMITTER_PKG = preload("uid://02wucdaons1k")   

class Utility:

	const GLOBAL_GROUP_PREFIX := "global_group/"
	static var _global_groups_cache: PackedStringArray = []

	## Returns an array of all the global groups in the project
	## and caches it.
	static func get_all_global_groups() -> PackedStringArray:
		var current_groups: PackedStringArray = []

		for prop in ProjectSettings.get_property_list():
			var _name: String = prop.name
			if _name.begins_with(GLOBAL_GROUP_PREFIX):
				current_groups.append(_name.substr(GLOBAL_GROUP_PREFIX.length()))
	
		if current_groups == _global_groups_cache:
			return _global_groups_cache
	
		for group in current_groups:
			if group not in _global_groups_cache:
				_global_groups_cache.append(group)
	
		return _global_groups_cache


class Emitters:

## error strings.
	static var string_names: Array = [
		&"default_listener_signal", &".", &" ", &"", null]
	static var debug_strings: Array[String] = [
		"No connections.", "connection list: ",
		"connected couples: ", "local", "global",  "\n"]

## prints the debug of the connection process of all emitter nodes.
	static func emitter_debug_connection(
		debug   : bool,       target : Object,
		_signal : StringName, strs   : Array[String], connect_log) -> void:

		if debug:
			var connect_list: Array[Dictionary] = target.get_signal_connection_list(_signal)
			var d_strings: Array[String] = [
				strs[1] + str(connect_list), strs[5],
				strs[2] + str(connect_log), strs[5] ]

			for s in d_strings: print(s)

## pushes warnings for all Emitter nodes.
	static func warning(warn: int, node_name: String = "") -> void: # DEBUG

		var warn_number: int = 1
		if warn > warn_number or warn < 0: return

		var msg_strings: Array[String] = [
			node_name + " is not connected, proceding." ,
			"group_to_check doesn't exist or requires correction. " ,
			"No CollisionObject3D child assigned. "]

		var formatted_strings: Array[String] = [
			str(msg_strings[1], msg_strings[0]),
			str(msg_strings[2], msg_strings[0])]

		var f_str_number: int = formatted_strings.size()

		for i in f_str_number: match i:
			warn: push_warning(formatted_strings[warn])
